package com.karthik;

import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		
		Stream<String> build = Stream.<String>builder().add("PK").add("PR").add("MK").build();
		build.forEach(System.out::println);
		
		System.out.println("==============");
		
		
		Stream<String> limit=Stream.generate(()->"Hello").limit(10);
		limit.forEach(System.out::println);
	}
}
