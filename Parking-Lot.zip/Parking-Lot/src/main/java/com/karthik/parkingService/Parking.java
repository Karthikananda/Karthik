package com.karthik.parkingService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.karthik.parking.GenerateId;
import com.karthik.parking.customer;

public class Parking {

       public static void main(String[] args) {
              ParkingService service=new ParkingService();
              service.addCar(new customer("Karthik","98768879876","6"));
              service.addCar(new customer("vishnu","98768879876","6"));
              service.addCar(new customer("nikhil","98768879876","6"));
              service.addCar(new customer("naveen","98768879876","6"));
              customer Customer=new customer("naveen","98768879876","6");
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            System.out.println(ser.addCar(new Customer("vishnu","98768879876","6")));
//            
       //System.out.println(ser.getAllCars());
              
              service.addCar(Customer);
      for (Map.Entry m :service.getAllCars() ) {
        System.out.println(m.getKey() + " " + m.getValue());
      }
        System.out.println(service.getcarById(Customer.getId()));
       
     // System.out.println(service.getcarById(customer.getId()));   

       }
}
