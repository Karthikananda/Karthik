package com.karthik.lambda;
public interface MyInterface2 {
	 public abstract boolean method2(int n1,int n2);
	}