package com.logtest;


public class CarServiceTest {
	
	
	public static void main(String[] args)
	{
		CarService car=new CarService();
		car.process("BMW");
	}

}
