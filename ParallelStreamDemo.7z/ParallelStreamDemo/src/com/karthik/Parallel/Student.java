package com.karthik.Parallel;

public class Student {
   private String Name;
   private int age;
public Student(String name, int age) {
	super();
	Name = name;
	this.age = age;
}
@Override
public String toString() {
	return "Student [Name=" + Name + ", age=" + age + "]";
}

	
}
