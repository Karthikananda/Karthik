package com.karthik.Parallel;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		List<Student> list = new ArrayList<>();
		list.add(new Student("Karthik",22));
		list.add(new Student("Ismail",22));
		list.add(new Student("Ram",22));
		list.add(new Student("Gagan",22));
		list.add(new Student("Vishnu",22));
		list.add(new Student("Nikhil",22));
		list.add(new Student("Naveen",22));
		
		Stream<Student> parallelStream = list.parallelStream();
		System.out.println("Students data send for processing:");
		parallelStream.forEach(s->doProcess(s));
	}

	private static void doProcess(Student s) {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

}
